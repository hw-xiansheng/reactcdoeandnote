import React, { Component } from 'react';

class App extends Component {
    render() {
        return (
            <div>
                我是脚手架！！！
            </div>
        );
    }
}

export default App;
